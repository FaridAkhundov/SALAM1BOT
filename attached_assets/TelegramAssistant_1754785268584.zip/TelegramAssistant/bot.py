"""
Telegram Bot for YouTube to MP3 conversion
"""

import os
import asyncio
import logging
from typing import Optional
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import Application, CommandHandler, MessageHandler, CallbackQueryHandler, ContextTypes, filters
from telegram.constants import ChatAction, ParseMode
from telegram.error import TelegramError

from config import Config
from youtube_downloader import YouTubeDownloader
from audio_converter import AudioConverter
from utils import is_youtube_url, format_file_size, cleanup_temp_files, ensure_directory

logger = logging.getLogger(__name__)

class TelegramBot:
    def __init__(self):
        self.token = Config.TELEGRAM_TOKEN
        self.downloader = YouTubeDownloader()
        self.converter = AudioConverter()
        self.application = None
        
        # Ensure temp directory exists
        ensure_directory(Config.TEMP_DIR)
    
    async def start(self):
        """Start the bot"""
        try:
            # Create application
            self.application = Application.builder().token(self.token).build()
            
            # Add handlers
            self.application.add_handler(CommandHandler("start", self.start_command))
            self.application.add_handler(CommandHandler("help", self.help_command))
            self.application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, self.handle_message))
            self.application.add_handler(CallbackQueryHandler(self.button_callback))
            
            # Start cleanup task
            asyncio.create_task(self.cleanup_task())
            
            logger.info("Bot started successfully")
            await self.application.run_polling(allowed_updates=Update.ALL_TYPES)
            
        except Exception as e:
            logger.error(f"Error starting bot: {e}")
            raise
    
    async def start_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /start command"""
        welcome_message = (
            "🎵 *Welcome to YouTube MP3 Bot!* 🎵\n\n"
            "Send me a YouTube link and I'll convert it to MP3 for you!\n\n"
            "🔗 *Supported formats:*\n"
            "• youtube.com/watch?v=...\n"
            "• youtu.be/...\n"
            "• youtube.com/embed/...\n\n"
            "📝 Use /help for more information."
        )
        
        await update.message.reply_text(
            welcome_message,
            parse_mode=ParseMode.MARKDOWN
        )
    
    async def help_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /help command"""
        help_message = (
            "🎵 *YouTube MP3 Bot Help* 🎵\n\n"
            "*How to use:*\n"
            "1. Send me a YouTube video link\n"
            "2. Wait for the download and conversion\n"
            "3. Receive your MP3 file!\n\n"
            "*Features:*\n"
            "• High quality audio extraction (192kbps)\n"
            "• Automatic file size optimization\n"
            "• Support for various YouTube URL formats\n"
            "• Fast processing\n\n"
            "*Limitations:*\n"
            "• Max file size: 50MB\n"
            "• Max video length: 1 hour\n"
            "• Audio only (no video files)\n\n"
            "*Commands:*\n"
            "/start - Show welcome message\n"
            "/help - Show this help\n\n"
            "Just send me a YouTube link to get started! 🚀"
        )
        
        await update.message.reply_text(
            help_message,
            parse_mode=ParseMode.MARKDOWN
        )
    
    async def handle_message(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle incoming messages"""
        try:
            message_text = update.message.text.strip()
            
            if is_youtube_url(message_text):
                await self.process_youtube_url(update, context, message_text)
            else:
                await update.message.reply_text(
                    "❌ Please send a valid YouTube URL.\n\n"
                    "Examples:\n"
                    "• https://youtube.com/watch?v=VIDEO_ID\n"
                    "• https://youtu.be/VIDEO_ID"
                )
        
        except Exception as e:
            logger.error(f"Error handling message: {e}")
            await update.message.reply_text(
                "❌ An error occurred while processing your message. Please try again."
            )
    
    async def process_youtube_url(self, update: Update, context: ContextTypes.DEFAULT_TYPE, url: str):
        """Process YouTube URL for download and conversion"""
        user_id = update.effective_user.id
        chat_id = update.effective_chat.id
        
        try:
            # Send initial processing message
            await context.bot.send_chat_action(chat_id=chat_id, action=ChatAction.TYPING)
            
            status_message = await update.message.reply_text(
                "🔍 *Getting video information...*",
                parse_mode=ParseMode.MARKDOWN
            )
            
            # Get video info
            video_info = await self.downloader.get_video_info(url)
            if not video_info:
                await status_message.edit_text("❌ Could not get video information. Please check the URL.")
                return
            
            # Show video info and ask for confirmation
            info_text = (
                f"📹 *Video Found!*\n\n"
                f"🎬 **Title:** {video_info['title'][:100]}{'...' if len(video_info['title']) > 100 else ''}\n"
                f"👤 **Uploader:** {video_info['uploader']}\n"
                f"⏱️ **Duration:** {self.format_duration(video_info['duration'])}\n\n"
                f"Convert to MP3?"
            )
            
            keyboard = [
                [InlineKeyboardButton("🎵 Download MP3", callback_data=f"download_{user_id}")]
            ]
            reply_markup = InlineKeyboardMarkup(keyboard)
            
            await status_message.edit_text(
                info_text,
                parse_mode=ParseMode.MARKDOWN,
                reply_markup=reply_markup
            )
            
            # Store URL in context for callback
            context.user_data[f"url_{user_id}"] = url
            
        except Exception as e:
            logger.error(f"Error processing YouTube URL: {e}")
            await update.message.reply_text(
                "❌ Error processing the YouTube URL. Please try again or check if the URL is valid."
            )
    
    async def button_callback(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle button callbacks"""
        query = update.callback_query
        await query.answer()
        
        try:
            data = query.data
            if data.startswith("download_"):
                user_id = int(data.split("_")[1])
                
                if user_id != update.effective_user.id:
                    await query.edit_message_text("❌ This button is not for you.")
                    return
                
                url = context.user_data.get(f"url_{user_id}")
                if not url:
                    await query.edit_message_text("❌ URL not found. Please send the YouTube link again.")
                    return
                
                await self.download_and_convert(query, context, url, user_id)
                
        except Exception as e:
            logger.error(f"Error in button callback: {e}")
            await query.edit_message_text("❌ An error occurred. Please try again.")
    
    async def download_and_convert(self, query, context: ContextTypes.DEFAULT_TYPE, url: str, user_id: int):
        """Download video and convert to MP3"""
        chat_id = query.message.chat_id
        
        try:
            # Update status
            await query.edit_message_text(
                "⬇️ *Downloading audio...*\n\n"
                "This may take a few minutes depending on video length.",
                parse_mode=ParseMode.MARKDOWN
            )
            
            await context.bot.send_chat_action(chat_id=chat_id, action=ChatAction.RECORD_VOICE)
            
            # Download audio
            download_result = await self.downloader.download_audio(url, user_id)
            if not download_result:
                await query.edit_message_text("❌ Failed to download audio. Please try again or check the URL.")
                return
            
            # Update status
            await query.edit_message_text(
                "🔄 *Converting to MP3...*\n\n"
                f"**Title:** {download_result['title'][:80]}{'...' if len(download_result['title']) > 80 else ''}\n"
                f"**Size:** {format_file_size(download_result['file_size'])}",
                parse_mode=ParseMode.MARKDOWN
            )
            
            await context.bot.send_chat_action(chat_id=chat_id, action=ChatAction.UPLOAD_VOICE)
            
            # Convert to MP3
            mp3_file = await self.converter.convert_to_mp3(download_result['filepath'], user_id)
            if not mp3_file:
                await query.edit_message_text("❌ Failed to convert to MP3. The file might be too large or corrupted.")
                self.downloader.cleanup_user_files(user_id)
                return
            
            # Check file size
            file_size = os.path.getsize(mp3_file)
            if file_size > Config.MAX_FILE_SIZE:
                await query.edit_message_text(
                    f"❌ File too large ({format_file_size(file_size)}). "
                    f"Maximum allowed size is {format_file_size(Config.MAX_FILE_SIZE)}."
                )
                self.downloader.cleanup_user_files(user_id)
                return
            
            # Send MP3 file
            await query.edit_message_text(
                "📤 *Sending MP3 file...*",
                parse_mode=ParseMode.MARKDOWN
            )
            
            # Get audio info for metadata
            audio_info = self.converter.get_audio_info(mp3_file)
            duration = int(audio_info['duration']) if audio_info else download_result.get('duration', 0)
            
            with open(mp3_file, 'rb') as audio_file:
                await context.bot.send_audio(
                    chat_id=chat_id,
                    audio=audio_file,
                    duration=duration,
                    performer=download_result.get('uploader', 'Unknown'),
                    title=download_result.get('title', 'Audio'),
                    caption=f"🎵 {download_result.get('title', 'Audio')}\n📁 Size: {format_file_size(file_size)}"
                )
            
            # Success message
            await query.edit_message_text(
                "✅ *Conversion completed successfully!*\n\n"
                f"🎵 **{download_result.get('title', 'Audio')}**\n"
                f"📁 **Size:** {format_file_size(file_size)}\n"
                f"🎤 **Uploader:** {download_result.get('uploader', 'Unknown')}",
                parse_mode=ParseMode.MARKDOWN
            )
            
        except TelegramError as e:
            logger.error(f"Telegram error: {e}")
            try:
                await query.edit_message_text(f"❌ Telegram error: {str(e)}")
            except:
                pass
        except Exception as e:
            logger.error(f"Error in download_and_convert: {e}")
            try:
                await query.edit_message_text("❌ An unexpected error occurred during processing.")
            except:
                pass
        finally:
            # Clean up user files
            self.downloader.cleanup_user_files(user_id)
    
    def format_duration(self, seconds: int) -> str:
        """Format duration from seconds to human readable format"""
        if seconds <= 0:
            return "Unknown"
        
        hours = seconds // 3600
        minutes = (seconds % 3600) // 60
        seconds = seconds % 60
        
        if hours > 0:
            return f"{hours}h {minutes}m {seconds}s"
        elif minutes > 0:
            return f"{minutes}m {seconds}s"
        else:
            return f"{seconds}s"
    
    async def cleanup_task(self):
        """Background task to clean up old files"""
        while True:
            try:
                await asyncio.sleep(3600)  # Run every hour
                cleanup_temp_files(Config.TEMP_DIR)
                logger.info("Completed scheduled cleanup")
            except Exception as e:
                logger.error(f"Error in cleanup task: {e}")
