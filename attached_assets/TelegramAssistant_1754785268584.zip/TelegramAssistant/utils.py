"""
Utility functions for the Telegram YouTube MP3 Bot
"""

import os
import re
import shutil
import logging
from typing import Optional

logger = logging.getLogger(__name__)

def is_youtube_url(url: str) -> bool:
    """Check if the provided URL is a valid YouTube URL"""
    youtube_patterns = [
        r'(?:https?://)?(?:www\.)?youtube\.com/watch\?v=[\w-]+',
        r'(?:https?://)?(?:www\.)?youtu\.be/[\w-]+',
        r'(?:https?://)?(?:www\.)?youtube\.com/embed/[\w-]+',
        r'(?:https?://)?(?:www\.)?youtube\.com/v/[\w-]+',
        r'(?:https?://)?(?:m\.)?youtube\.com/watch\?v=[\w-]+',
        # Support for URLs with additional parameters (playlists, timestamps, etc.)
        r'(?:https?://)?(?:www\.)?youtube\.com/watch\?v=[\w-]+(?:&[\w=&-]*)?',
        r'(?:https?://)?(?:m\.)?youtube\.com/watch\?v=[\w-]+(?:&[\w=&-]*)?',
    ]
    
    for pattern in youtube_patterns:
        if re.search(pattern, url, re.IGNORECASE):
            return True
    return False

def sanitize_filename(filename: str) -> str:
    """Remove or replace invalid characters from filename"""
    # Remove or replace invalid characters
    invalid_chars = '<>:"/\\|?*'
    for char in invalid_chars:
        filename = filename.replace(char, '_')
    
    # Remove multiple spaces and trim
    filename = re.sub(r'\s+', ' ', filename).strip()
    
    # Limit filename length
    if len(filename) > 200:
        filename = filename[:200]
    
    return filename

def get_file_size(filepath: str) -> int:
    """Get file size in bytes"""
    try:
        return os.path.getsize(filepath)
    except OSError:
        return 0

def cleanup_temp_files(temp_dir: str, max_age_hours: int = 1):
    """Clean up old temporary files"""
    try:
        import time
        current_time = time.time()
        max_age_seconds = max_age_hours * 3600
        
        if not os.path.exists(temp_dir):
            return
            
        for filename in os.listdir(temp_dir):
            filepath = os.path.join(temp_dir, filename)
            try:
                file_age = current_time - os.path.getmtime(filepath)
                if file_age > max_age_seconds:
                    if os.path.isfile(filepath):
                        os.remove(filepath)
                    elif os.path.isdir(filepath):
                        shutil.rmtree(filepath)
                    logger.info(f"Cleaned up old file: {filepath}")
            except OSError as e:
                logger.warning(f"Failed to clean up {filepath}: {e}")
    except Exception as e:
        logger.error(f"Error during cleanup: {e}")

def ensure_directory(directory: str):
    """Ensure directory exists"""
    try:
        os.makedirs(directory, exist_ok=True)
    except OSError as e:
        logger.error(f"Failed to create directory {directory}: {e}")
        raise

def format_file_size(size_bytes: int) -> str:
    """Format file size in human readable format"""
    if size_bytes == 0:
        return "0 B"
    
    size_names = ["B", "KB", "MB", "GB"]
    i = 0
    while size_bytes >= 1024 and i < len(size_names) - 1:
        size_bytes /= 1024.0
        i += 1
    
    return f"{size_bytes:.1f} {size_names[i]}"

def extract_video_id(url: str) -> Optional[str]:
    """Extract YouTube video ID from URL, handling playlist and other parameters"""
    patterns = [
        r'(?:youtube\.com/watch\?v=|youtu\.be/|youtube\.com/embed/|youtube\.com/v/)([a-zA-Z0-9_-]{11})',
        r'[?&]v=([a-zA-Z0-9_-]{11})',
    ]
    
    for pattern in patterns:
        match = re.search(pattern, url)
        if match:
            video_id = match.group(1)
            # Ensure it's exactly 11 characters (YouTube video ID standard)
            if len(video_id) == 11:
                return video_id
    
    return None

def clean_youtube_url(url: str) -> str:
    """Clean YouTube URL by removing playlist and other unnecessary parameters"""
    video_id = extract_video_id(url)
    if video_id:
        return f"https://www.youtube.com/watch?v={video_id}"
    return url
