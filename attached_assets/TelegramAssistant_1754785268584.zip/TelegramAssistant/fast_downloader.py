"""
Fast YouTube downloader with optimized approach
"""

import asyncio
import logging
import os
import subprocess
import tempfile
from typing import Optional, Dict, Any
import yt_dlp
import time

logger = logging.getLogger(__name__)

class FastYouTubeDownloader:
    """Optimized YouTube downloader focused on speed and reliability"""
    
    def __init__(self):
        self.temp_dir = "temp_downloads"
        os.makedirs(self.temp_dir, exist_ok=True)
        
        # Optimized options for speed and bypass
        self.base_options = {
            'quiet': True,
            'no_warnings': True,
            'extract_flat': False,
            'socket_timeout': 10,
            'extractor_retries': 1,
            'fragment_retries': 1,
            'format': 'bestaudio[ext=m4a]/bestaudio/best',
            'postprocessors': [{
                'key': 'FFmpegExtractAudio',
                'preferredcodec': 'mp3',
                'preferredquality': '192',
            }],
            'extractor_args': {
                'youtube': {
                    'player_client': ['android_music', 'android_testsuite']
                }
            },
            'http_headers': {
                'User-Agent': 'com.google.android.youtube.music/5.16.51 (Linux; U; Android 10; TR) gzip'
            }
        }
    
    async def quick_extract_info(self, url: str) -> Optional[Dict[str, Any]]:
        """Quick info extraction with timeout"""
        try:
            options = self.base_options.copy()
            options.update({
                'skip_download': True,
                'extract_flat': False
            })
            
            # Use timeout to prevent hanging
            loop = asyncio.get_event_loop()
            task = loop.run_in_executor(None, self._extract_info_sync, url, options)
            
            try:
                info = await asyncio.wait_for(task, timeout=15.0)  # 15 second timeout
                if info:
                    return {
                        'title': info.get('title', 'Unknown'),
                        'duration': info.get('duration', 0),
                        'uploader': info.get('uploader', 'Unknown'),
                    }
            except asyncio.TimeoutError:
                logger.warning("Info extraction timed out")
                return None
                
        except Exception as e:
            logger.error(f"Quick info extraction failed: {e}")
            return None
    
    def _extract_info_sync(self, url: str, options: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Synchronous info extraction"""
        try:
            with yt_dlp.YoutubeDL(options) as ydl:
                return ydl.extract_info(url, download=False)
        except Exception as e:
            logger.debug(f"Sync extraction failed: {e}")
            return None
    
    async def fast_download(self, url: str, user_id: int) -> Optional[Dict[str, Any]]:
        """Fast download with aggressive timeout and fallbacks"""
        user_temp_dir = os.path.join(self.temp_dir, str(user_id))
        os.makedirs(user_temp_dir, exist_ok=True)
        
        # Try multiple fast strategies
        strategies = [
            self._strategy_android_music,
            self._strategy_simple_best,
            self._strategy_fallback
        ]
        
        for i, strategy in enumerate(strategies):
            try:
                logger.info(f"Trying download strategy {i+1}")
                
                options = strategy()
                options['outtmpl'] = os.path.join(user_temp_dir, '%(title)s.%(ext)s')
                
                # Use shorter timeout for each attempt
                loop = asyncio.get_event_loop()
                task = loop.run_in_executor(None, self._download_sync, url, options)
                
                try:
                    result = await asyncio.wait_for(task, timeout=30.0)  # 30 second timeout
                    if result:
                        return result
                except asyncio.TimeoutError:
                    logger.warning(f"Strategy {i+1} timed out")
                    continue
                    
            except Exception as e:
                logger.warning(f"Strategy {i+1} failed: {e}")
                continue
        
        return None
    
    def _download_sync(self, url: str, options: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Synchronous download"""
        try:
            with yt_dlp.YoutubeDL(options) as ydl:
                info = ydl.extract_info(url, download=True)
                
                if info:
                    # Find the output file
                    temp_dir = os.path.dirname(options['outtmpl'])
                    for file in os.listdir(temp_dir):
                        if file.endswith('.mp3'):
                            filepath = os.path.join(temp_dir, file)
                            return {
                                'filename': filepath,
                                'title': info.get('title', 'Unknown'),
                                'duration': info.get('duration', 0),
                                'uploader': info.get('uploader', 'Unknown')
                            }
                            
        except Exception as e:
            logger.debug(f"Sync download failed: {e}")
            return None
    
    def _strategy_android_music(self) -> Dict[str, Any]:
        """Android Music client strategy"""
        return {
            'quiet': True,
            'no_warnings': True,
            'format': 'bestaudio[ext=m4a]/bestaudio',
            'postprocessors': [{
                'key': 'FFmpegExtractAudio',
                'preferredcodec': 'mp3',
                'preferredquality': '128',
            }],
            'extractor_args': {
                'youtube': {
                    'player_client': ['android_music']
                }
            },
            'http_headers': {
                'User-Agent': 'com.google.android.youtube.music/5.16.51 (Linux; U; Android 10; TR) gzip'
            }
        }
    
    def _strategy_simple_best(self) -> Dict[str, Any]:
        """Simple best quality strategy"""
        return {
            'quiet': True,
            'no_warnings': True,
            'format': 'best[height<=480]/best',
            'postprocessors': [{
                'key': 'FFmpegExtractAudio',
                'preferredcodec': 'mp3',
                'preferredquality': '128',
            }],
            'extractor_args': {
                'youtube': {
                    'player_client': ['android_testsuite']
                }
            }
        }
    
    def _strategy_fallback(self) -> Dict[str, Any]:
        """Fallback strategy with minimal options"""
        return {
            'quiet': True,
            'format': 'worst[ext=mp4]/worst',
            'postprocessors': [{
                'key': 'FFmpegExtractAudio',
                'preferredcodec': 'mp3',
                'preferredquality': '96',
            }]
        }
    
    async def get_video_duration_fast(self, url: str) -> int:
        """Get video duration quickly"""
        try:
            # Use yt-dlp to get just duration info
            cmd = [
                'yt-dlp', '--get-duration', '--quiet', 
                '--extractor-args', 'youtube:player_client=android_music',
                url
            ]
            
            process = await asyncio.create_subprocess_exec(
                *cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            
            try:
                stdout, _ = await asyncio.wait_for(process.communicate(), timeout=10.0)
                duration_str = stdout.decode().strip()
                
                # Parse duration (format: HH:MM:SS or MM:SS)
                parts = duration_str.split(':')
                if len(parts) == 3:  # HH:MM:SS
                    return int(parts[0]) * 3600 + int(parts[1]) * 60 + int(parts[2])
                elif len(parts) == 2:  # MM:SS
                    return int(parts[0]) * 60 + int(parts[1])
                    
            except asyncio.TimeoutError:
                process.kill()
                
        except Exception as e:
            logger.debug(f"Fast duration check failed: {e}")
            
        return 0