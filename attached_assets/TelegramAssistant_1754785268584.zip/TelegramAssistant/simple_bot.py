"""
Simple Telegram Bot for YouTube to MP3 conversion
Using basic telegram bot API without complex ext modules
"""

import os
import asyncio
import logging
import json
import aiohttp
from typing import Optional
from urllib.parse import urlparse

from config import Config
from fast_downloader import FastYouTubeDownloader
from audio_converter import AudioConverter
from utils import is_youtube_url, clean_youtube_url, format_file_size, cleanup_temp_files, ensure_directory

logger = logging.getLogger(__name__)

class SimpleTelegramBot:
    def __init__(self):
        self.token = Config.TELEGRAM_TOKEN
        self.api_url = f"https://api.telegram.org/bot{self.token}"
        self.downloader = FastYouTubeDownloader()
        self.converter = AudioConverter()
        self.session = None
        self.offset = 0
        
        # Ensure temp directory exists
        ensure_directory(Config.TEMP_DIR)
    
    async def start(self):
        """Start the bot"""
        try:
            self.session = aiohttp.ClientSession()
            
            logger.info("Bot started successfully")
            
            # Start cleanup task
            asyncio.create_task(self.cleanup_task())
            
            # Start polling
            await self.poll_updates()
            
        except Exception as e:
            logger.error(f"Error starting bot: {e}")
            raise
        finally:
            if self.session:
                await self.session.close()
    
    async def poll_updates(self):
        """Poll for updates from Telegram"""
        while True:
            try:
                url = f"{self.api_url}/getUpdates"
                params = {
                    'offset': self.offset,
                    'timeout': 30,
                    'allowed_updates': json.dumps(['message', 'callback_query'])
                }
                
                async with self.session.get(url, params=params) as response:
                    if response.status == 200:
                        data = await response.json()
                        if data['ok']:
                            updates = data['result']
                            for update in updates:
                                self.offset = update['update_id'] + 1
                                await self.handle_update(update)
                    else:
                        logger.error(f"Failed to get updates: {response.status}")
                        await asyncio.sleep(5)
                        
            except Exception as e:
                logger.error(f"Error polling updates: {e}")
                await asyncio.sleep(5)
    
    async def handle_update(self, update):
        """Handle incoming update"""
        try:
            if 'message' in update:
                await self.handle_message(update['message'])
            elif 'callback_query' in update:
                await self.handle_callback_query(update['callback_query'])
        except Exception as e:
            logger.error(f"Error handling update: {e}")
    
    async def handle_message(self, message):
        """Handle incoming message"""
        try:
            chat_id = message['chat']['id']
            
            if 'text' not in message:
                return
                
            text = message['text'].strip()
            
            # Handle commands
            if text.startswith('/start'):
                await self.send_start_message(chat_id)
            elif text.startswith('/help'):
                await self.send_help_message(chat_id)
            elif is_youtube_url(text):
                # Clean the URL to remove playlist and other parameters
                clean_url = clean_youtube_url(text)
                await self.process_youtube_url(chat_id, clean_url, message['from']['id'])
            else:
                await self.send_message(chat_id, 
                    "❌ Please send a valid YouTube URL.\n\n"
                    "Examples:\n"
                    "• https://youtube.com/watch?v=VIDEO_ID\n"
                    "• https://youtu.be/VIDEO_ID"
                )
        except Exception as e:
            logger.error(f"Error handling message: {e}")
    
    async def send_start_message(self, chat_id):
        """Send start message"""
        message = (
            "🎵 *MrMusicAze'ye Hoş Geldiniz!* 🎵\n\n"
            "YouTube videolarını MP3 formatına çevirmek için YouTube linkini gönderin!\n\n"
            "🔗 *Desteklenen formatlar:*\n"
            "• youtube.com/watch?v=...\n"
            "• youtu.be/...\n"
            "• youtube.com/embed/...\n\n"
            "⚠️ *Önemli:* YouTube'un güvenlik sistemleri nedeniyle bazen indirme başarısız olabilir. "
            "Bu durumda farklı videolar deneyebilir veya birkaç dakika bekleyip tekrar deneyebilirsiniz.\n\n"
            "📝 Daha fazla bilgi için /help kullanın."
        )
        await self.send_message(chat_id, message, parse_mode='Markdown')
    
    async def send_help_message(self, chat_id):
        """Send help message"""
        message = (
            "🎵 *YouTube MP3 Bot Yardım* 🎵\n\n"
            "*Nasıl kullanılır:*\n"
            "1. Bana bir YouTube video linki gönderin\n"
            "2. İndirme ve dönüştürme işlemini bekleyin\n"
            "3. MP3 dosyanızı alın!\n\n"
            "*Özellikler:*\n"
            "• Yüksek kalite ses çıkarma (192kbps)\n"
            "• Otomatik dosya boyutu optimizasyonu\n"
            "• Çeşitli YouTube URL formatları desteği\n"
            "• Hızlı işleme\n\n"
            "*Sınırlamalar:*\n"
            "• Maksimum dosya boyutu: 50MB\n"
            "• Maksimum video uzunluğu: 1 saat\n"
            "• Sadece ses dosyaları (video yok)\n\n"
            "*YouTube Kısıtlamaları:*\n"
            "• YouTube'un bot algılama sistemi bazen indirmeyi engelleyebilir\n"
            "• Bu durumda birkaç dakika bekleyip tekrar deneyin\n"
            "• Farklı videolar deneyin\n\n"
            "*Komutlar:*\n"
            "/start - Hoş geldin mesajı\n"
            "/help - Bu yardım mesajı\n\n"
            "Başlamak için sadece YouTube linki gönderin! 🚀"
        )
        await self.send_message(chat_id, message, parse_mode='Markdown')
    
    async def process_youtube_url(self, chat_id, url, user_id):
        """Process YouTube URL"""
        try:
            # Send initial message
            status_response = await self.send_message(chat_id, 
                "🔍 *Getting video information...*", 
                parse_mode='Markdown'
            )
            status_msg = status_response['result'] if status_response and status_response.get('ok') else None
            
            # Get video info quickly
            video_info = await self.downloader.quick_extract_info(url)
            if not video_info:
                error_msg = (
                    "❌ *YouTube İndirme Sorunu*\n\n"
                    "🔒 YouTube'un bot algılama sistemi aktif ve indirmeyi engelliyor.\n\n"
                    "✅ *Çözüm önerileri:*\n"
                    "• Birkaç dakika bekleyip tekrar deneyin\n"
                    "• Farklı bir YouTube videosu deneyin\n"
                    "• Daha kısa videolar seçin\n\n"
                    "🤖 Bot sürekli güncellenmektedir..."
                )
                if status_msg:
                    await self.edit_message(chat_id, status_msg['message_id'], error_msg, parse_mode='Markdown')
                else:
                    await self.send_message(chat_id, error_msg, parse_mode='Markdown')
                return
            
            # Show info and start download
            info_text = (
                f"📹 *Video Found!*\n\n"
                f"🎬 **Title:** {video_info['title'][:100]}{'...' if len(video_info['title']) > 100 else ''}\n"
                f"👤 **Uploader:** {video_info['uploader']}\n"
                f"⏱️ **Duration:** {self.format_duration(video_info['duration'])}\n\n"
                f"⬇️ Starting download..."
            )
            
            if status_msg:
                await self.edit_message(chat_id, status_msg['message_id'], info_text, parse_mode='Markdown')
                message_id = status_msg['message_id']
            else:
                new_msg = await self.send_message(chat_id, info_text, parse_mode='Markdown')
                message_id = new_msg['result']['message_id'] if new_msg and new_msg.get('ok') else None
            
            # Download and convert with fast method
            await self.download_and_convert_fast(chat_id, message_id, url, user_id)
            
        except Exception as e:
            logger.error(f"Error processing YouTube URL: {e}")
            await self.send_message(chat_id, 
                "❌ Error processing the YouTube URL. Please try again.")
    
    async def download_and_convert_fast(self, chat_id, message_id, url, user_id):
        """Fast download and convert video"""
        try:
            # Download with fast method
            if message_id:
                await self.edit_message(chat_id, message_id,
                    "⬇️ *Hızlı indirme başlıyor...*\n\nBu işlem 30 saniye sürebilir.",
                    parse_mode='Markdown'
                )
            else:
                await self.send_message(chat_id, "⬇️ *Hızlı indirme başlıyor...*", parse_mode='Markdown')
            
            # Use fast downloader
            result = await self.downloader.fast_download(url, user_id)
            
            if not result:
                error_msg = (
                    "❌ *İndirme Başarısız*\n\n"
                    "YouTube'un güvenlik kısıtlamaları nedeniyle video indirilemedi.\n\n"
                    "💡 *Deneyebilirsiniz:*\n"
                    "• Farklı bir YouTube videosu\n"
                    "• 5-10 dakika bekleyip tekrar deneme\n"
                    "• Daha popüler/yeni videolar"
                )
                if message_id:
                    await self.edit_message(chat_id, message_id, error_msg, parse_mode='Markdown')
                else:
                    await self.send_message(chat_id, error_msg, parse_mode='Markdown')
                return
            
            # Check file size
            file_size = os.path.getsize(result['filename'])
            if file_size > Config.MAX_FILE_SIZE:
                await self.send_message(chat_id, 
                    f"❌ Dosya çok büyük ({format_file_size(file_size)}). "
                    f"Maksimum: {format_file_size(Config.MAX_FILE_SIZE)}")
                return
            
            # Send file
            if message_id:
                await self.edit_message(chat_id, message_id,
                    "📤 *MP3 gönderiliyor...*",
                    parse_mode='Markdown'
                )
            
            success = await self.send_audio_file(chat_id, result['filename'], result)
            
            if success:
                success_msg = (
                    f"✅ *Başarılı!*\n\n"
                    f"🎵 **{result['title'][:50]}{'...' if len(result['title']) > 50 else ''}**\n"
                    f"📊 Boyut: {format_file_size(file_size)}"
                )
                if message_id:
                    await self.edit_message(chat_id, message_id, success_msg, parse_mode='Markdown')
                else:
                    await self.send_message(chat_id, success_msg, parse_mode='Markdown')
            else:
                await self.send_message(chat_id, "❌ MP3 dosyası gönderilemedi. Tekrar deneyin.")
            
            # Cleanup
            try:
                if os.path.exists(result['filename']):
                    os.remove(result['filename'])
            except Exception as e:
                logger.warning(f"Cleanup failed: {e}")
                
        except Exception as e:
            logger.error(f"Error in fast download: {e}")
            await self.send_message(chat_id, 
                "❌ Bir hata oluştu. Farklı bir video ile tekrar deneyin.")
    
    async def download_and_convert_old(self, chat_id, message_id, url, user_id):
        """Download and convert video"""
        try:
            # Download audio
            if message_id:
                await self.edit_message(chat_id, message_id,
                    "⬇️ *Downloading audio...*\n\n"
                    "This may take a few minutes depending on video length.",
                    parse_mode='Markdown'
                )
            else:
                await self.send_message(chat_id, "⬇️ *Downloading audio...*", parse_mode='Markdown')
            
            download_result = await self.downloader.download_audio(url, user_id)
            if not download_result:
                await self.edit_message(chat_id, message_id,
                    "❌ Failed to download audio. Please try again or check the URL.")
                return
            
            # Convert to MP3
            await self.edit_message(chat_id, message_id,
                f"🔄 *Converting to MP3...*\n\n"
                f"**Title:** {download_result['title'][:80]}{'...' if len(download_result['title']) > 80 else ''}\n"
                f"**Size:** {format_file_size(download_result['file_size'])}",
                parse_mode='Markdown'
            )
            
            mp3_file = await self.converter.convert_to_mp3(download_result['filepath'], user_id)
            if not mp3_file:
                await self.edit_message(chat_id, message_id,
                    "❌ Failed to convert to MP3. The file might be too large or corrupted.")
                self.downloader.cleanup_user_files(user_id)
                return
            
            # Check file size
            file_size = os.path.getsize(mp3_file)
            if file_size > Config.MAX_FILE_SIZE:
                await self.edit_message(chat_id, message_id,
                    f"❌ File too large ({format_file_size(file_size)}). "
                    f"Maximum allowed size is {format_file_size(Config.MAX_FILE_SIZE)}."
                )
                self.downloader.cleanup_user_files(user_id)
                return
            
            # Send file
            await self.edit_message(chat_id, message_id,
                "📤 *Sending MP3 file...*",
                parse_mode='Markdown'
            )
            
            await self.send_audio_file(chat_id, mp3_file, download_result)
            
            # Success message
            await self.edit_message(chat_id, message_id,
                "✅ *Conversion completed successfully!*\n\n"
                f"🎵 **{download_result.get('title', 'Audio')}**\n"
                f"📁 **Size:** {format_file_size(file_size)}\n"
                f"🎤 **Uploader:** {download_result.get('uploader', 'Unknown')}",
                parse_mode='Markdown'
            )
            
        except Exception as e:
            logger.error(f"Error in download_and_convert: {e}")
            try:
                await self.edit_message(chat_id, message_id,
                    "❌ An unexpected error occurred during processing.")
            except:
                pass
        finally:
            # Clean up user files
            self.downloader.cleanup_user_files(user_id)
    
    async def send_message(self, chat_id, text, parse_mode=None):
        """Send a message"""
        url = f"{self.api_url}/sendMessage"
        data = {
            'chat_id': chat_id,
            'text': text
        }
        if parse_mode:
            data['parse_mode'] = parse_mode
        
        async with self.session.post(url, data=data) as response:
            if response.status == 200:
                return await response.json()
            else:
                logger.error(f"Failed to send message: {response.status}")
                return None
    
    async def edit_message(self, chat_id, message_id, text, parse_mode=None):
        """Edit a message"""
        url = f"{self.api_url}/editMessageText"
        data = {
            'chat_id': chat_id,
            'message_id': message_id,
            'text': text
        }
        if parse_mode:
            data['parse_mode'] = parse_mode
        
        async with self.session.post(url, data=data) as response:
            if response.status == 200:
                return await response.json()
            else:
                logger.error(f"Failed to edit message: {response.status}")
                return None
    
    async def send_audio_file(self, chat_id, file_path, metadata):
        """Send audio file"""
        url = f"{self.api_url}/sendAudio"
        
        with open(file_path, 'rb') as audio_file:
            data = aiohttp.FormData()
            data.add_field('chat_id', str(chat_id))
            data.add_field('audio', audio_file, filename=os.path.basename(file_path))
            data.add_field('title', metadata.get('title', 'Audio'))
            data.add_field('performer', metadata.get('uploader', 'Unknown'))
            data.add_field('caption', f"🎵 {metadata.get('title', 'Audio')}\n📁 Size: {format_file_size(os.path.getsize(file_path))}")
            
            async with self.session.post(url, data=data) as response:
                if response.status == 200:
                    return await response.json()
                else:
                    logger.error(f"Failed to send audio: {response.status}")
                    return None
    
    def format_duration(self, seconds: int) -> str:
        """Format duration from seconds to human readable format"""
        if seconds <= 0:
            return "Unknown"
        
        hours = seconds // 3600
        minutes = (seconds % 3600) // 60
        seconds = seconds % 60
        
        if hours > 0:
            return f"{hours}h {minutes}m {seconds}s"
        elif minutes > 0:
            return f"{minutes}m {seconds}s"
        else:
            return f"{seconds}s"
    
    async def handle_callback_query(self, callback_query):
        """Handle callback query"""
        # For now, just acknowledge
        url = f"{self.api_url}/answerCallbackQuery"
        data = {'callback_query_id': callback_query['id']}
        async with self.session.post(url, data=data) as response:
            pass
    
    async def cleanup_task(self):
        """Background task to clean up old files"""
        while True:
            try:
                await asyncio.sleep(3600)  # Run every hour
                cleanup_temp_files(Config.TEMP_DIR)
                logger.info("Completed scheduled cleanup")
            except Exception as e:
                logger.error(f"Error in cleanup task: {e}")