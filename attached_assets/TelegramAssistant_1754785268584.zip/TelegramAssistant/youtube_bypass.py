"""
Enhanced YouTube bypass strategies
"""

import asyncio
import logging
import random
import time
from typing import Optional, Dict, Any
import yt_dlp

logger = logging.getLogger(__name__)

class YouTubeBypass:
    """Advanced YouTube restriction bypass"""
    
    def __init__(self):
        self.user_agents = [
            'com.google.android.youtube/19.09.37 (Linux; U; Android 11; TR) gzip',
            'com.google.android.youtube.tvunplugged/1.39.80.3 (Linux; U; Android 10; GB) gzip',
            'com.google.android.youtube/18.11.34 (Linux; U; Android 12; US) gzip',
            'Mozilla/5.0 (Android 11; Mobile; rv:68.0) Gecko/68.0 Firefox/88.0',
            'com.google.android.youtube.music/5.16.51 (Linux; U; Android 10; TR) gzip'
        ]
        
        self.extraction_strategies = [
            self._strategy_android_testsuite,
            self._strategy_android_embedded,
            self._strategy_android_music,
            self._strategy_tv_html5_embedded,
            self._strategy_android_creator
        ]
    
    async def extract_with_bypass(self, url: str) -> Optional[Dict[str, Any]]:
        """Try multiple extraction strategies"""
        
        for i, strategy in enumerate(self.extraction_strategies):
            try:
                logger.info(f"Trying extraction strategy {i+1}/{len(self.extraction_strategies)}")
                
                # Add random delay between attempts
                if i > 0:
                    delay = random.uniform(1, 3)
                    await asyncio.sleep(delay)
                
                loop = asyncio.get_event_loop()
                result = await loop.run_in_executor(None, strategy, url)
                
                if result:
                    logger.info(f"Successfully extracted with strategy {i+1}")
                    return result
                    
            except Exception as e:
                logger.warning(f"Strategy {i+1} failed: {e}")
                continue
                
        logger.error("All extraction strategies failed")
        return None
    
    def _strategy_android_testsuite(self, url: str) -> Optional[Dict[str, Any]]:
        """Android testsuite client - most reliable"""
        options = {
            'quiet': True,
            'no_warnings': True,
            'extractor_args': {
                'youtube': {
                    'player_client': ['android_testsuite'],
                    'player_skip': ['dash', 'hls', 'configs', 'webpage']
                }
            },
            'http_headers': {
                'User-Agent': 'com.google.android.youtube.tvunplugged/1.39.80.3 (Linux; U; Android 10; GB) gzip',
                'X-YouTube-Client-Name': '56',
                'X-YouTube-Client-Version': '1.39.80.3'
            }
        }
        return self._extract_with_options(url, options)
    
    def _strategy_android_embedded(self, url: str) -> Optional[Dict[str, Any]]:
        """Android embedded client"""
        options = {
            'quiet': True,
            'no_warnings': True,
            'extractor_args': {
                'youtube': {
                    'player_client': ['android_embedded'],
                    'player_skip': ['dash', 'hls']
                }
            },
            'http_headers': {
                'User-Agent': random.choice(self.user_agents),
                'Accept': '*/*',
                'Accept-Language': 'en-US,en;q=0.9,tr;q=0.8',
                'Accept-Encoding': 'gzip, deflate',
                'Origin': 'https://www.youtube.com',
                'Referer': 'https://www.youtube.com/'
            }
        }
        return self._extract_with_options(url, options)
    
    def _strategy_android_music(self, url: str) -> Optional[Dict[str, Any]]:
        """Android music client"""
        options = {
            'quiet': True,
            'no_warnings': True,
            'extractor_args': {
                'youtube': {
                    'player_client': ['android_music'],
                    'player_skip': ['configs']
                }
            },
            'http_headers': {
                'User-Agent': 'com.google.android.youtube.music/5.16.51 (Linux; U; Android 10; TR) gzip',
                'X-YouTube-Client-Name': '21',
                'X-YouTube-Client-Version': '5.16.51'
            }
        }
        return self._extract_with_options(url, options)
    
    def _strategy_tv_html5_embedded(self, url: str) -> Optional[Dict[str, Any]]:
        """TV HTML5 embedded client"""
        options = {
            'quiet': True,
            'no_warnings': True,
            'extractor_args': {
                'youtube': {
                    'player_client': ['tv_html5_embedded'],
                    'player_skip': ['dash', 'hls']
                }
            },
            'http_headers': {
                'User-Agent': 'Mozilla/5.0 (ChromiumStylePlatform) Cobalt/40.13031.2 (unlike Gecko) v8/8.5.210 gzip',
                'Accept': '*/*'
            }
        }
        return self._extract_with_options(url, options)
    
    def _strategy_android_creator(self, url: str) -> Optional[Dict[str, Any]]:
        """Android creator client - good for restricted content"""
        options = {
            'quiet': True,
            'no_warnings': True,
            'age_limit': 999,
            'extractor_args': {
                'youtube': {
                    'player_client': ['android_creator'],
                    'player_skip': ['configs', 'webpage']
                }
            },
            'http_headers': {
                'User-Agent': 'com.google.android.youtube/19.09.37 (Linux; U; Android 11; TR) gzip',
                'X-YouTube-Client-Name': '14',
                'X-YouTube-Client-Version': '22.30.100'
            }
        }
        return self._extract_with_options(url, options)
    
    def _extract_with_options(self, url: str, options: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Extract with given options"""
        try:
            with yt_dlp.YoutubeDL(options) as ydl:
                info = ydl.extract_info(url, download=False)
                return info
        except Exception as e:
            logger.debug(f"Extraction failed: {e}")
            return None
    
    async def download_with_bypass(self, url: str, output_path: str) -> Optional[Dict[str, Any]]:
        """Download with bypass strategies"""
        
        # First get video info
        info = await self.extract_with_bypass(url)
        if not info:
            return None
        
        # Try download with different strategies
        for i, strategy in enumerate(self.extraction_strategies):
            try:
                logger.info(f"Trying download strategy {i+1}")
                
                if i > 0:
                    delay = random.uniform(2, 5)
                    await asyncio.sleep(delay)
                
                # Configure download options
                download_options = self._get_download_options(strategy, output_path, info)
                
                loop = asyncio.get_event_loop()
                result = await loop.run_in_executor(None, self._download_with_options, url, download_options)
                
                if result:
                    logger.info(f"Successfully downloaded with strategy {i+1}")
                    return result
                    
            except Exception as e:
                logger.warning(f"Download strategy {i+1} failed: {e}")
                continue
                
        return None
    
    def _get_download_options(self, strategy_func, output_path: str, info: Dict) -> Dict[str, Any]:
        """Get download options for specific strategy"""
        base_options = {
            'format': 'bestaudio/best',
            'outtmpl': output_path,
            'extractaudio': True,
            'audioformat': 'mp3',
            'quiet': True,
            'no_warnings': True
        }
        
        # Get strategy-specific options
        strategy_name = strategy_func.__name__.split('_')[-1]
        
        if strategy_name == 'testsuite':
            base_options.update({
                'extractor_args': {
                    'youtube': {
                        'player_client': ['android_testsuite'],
                        'player_skip': ['dash', 'hls', 'configs', 'webpage']
                    }
                },
                'http_headers': {
                    'User-Agent': 'com.google.android.youtube.tvunplugged/1.39.80.3 (Linux; U; Android 10; GB) gzip'
                }
            })
        elif strategy_name == 'embedded':
            base_options.update({
                'extractor_args': {
                    'youtube': {
                        'player_client': ['android_embedded']
                    }
                },
                'http_headers': {
                    'User-Agent': random.choice(self.user_agents)
                }
            })
        elif strategy_name == 'music':
            base_options.update({
                'extractor_args': {
                    'youtube': {
                        'player_client': ['android_music']
                    }
                }
            })
        
        return base_options
    
    def _download_with_options(self, url: str, options: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Download with specific options"""
        try:
            with yt_dlp.YoutubeDL(options) as ydl:
                info = ydl.extract_info(url, download=True)
                return info
        except Exception as e:
            logger.debug(f"Download failed: {e}")
            return None