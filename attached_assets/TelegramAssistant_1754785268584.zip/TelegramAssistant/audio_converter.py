"""
Audio converter using ffmpeg
"""

import os
import asyncio
import logging
from typing import Optional
import ffmpeg
from config import Config
from utils import sanitize_filename, get_file_size

logger = logging.getLogger(__name__)

class AudioConverter:
    def __init__(self):
        self.bitrate = Config.AUDIO_BITRATE
        self.format = Config.AUDIO_FORMAT
    
    async def convert_to_mp3(self, input_file: str, user_id: int) -> Optional[str]:
        """Convert audio/video file to MP3"""
        try:
            if not os.path.exists(input_file):
                logger.error(f"Input file does not exist: {input_file}")
                return None
            
            # Generate output filename
            base_name = os.path.splitext(os.path.basename(input_file))[0]
            base_name = sanitize_filename(base_name)
            output_file = os.path.join(
                os.path.dirname(input_file),
                f"{base_name}.mp3"
            )
            
            # If input is already MP3 and within size limits, return as-is
            if input_file.lower().endswith('.mp3'):
                file_size = get_file_size(input_file)
                if file_size <= Config.MAX_FILE_SIZE:
                    logger.info(f"File is already MP3 and within size limits: {input_file}")
                    return input_file
            
            # Convert using ffmpeg
            loop = asyncio.get_event_loop()
            success = await loop.run_in_executor(
                None,
                self._convert_with_ffmpeg,
                input_file,
                output_file
            )
            
            if success and os.path.exists(output_file):
                # Check file size
                file_size = get_file_size(output_file)
                if file_size > Config.MAX_FILE_SIZE:
                    logger.warning(f"Converted file too large: {file_size} bytes")
                    # Try with lower bitrate
                    lower_bitrate_file = await self._convert_with_lower_bitrate(
                        input_file, output_file, user_id
                    )
                    if lower_bitrate_file:
                        return lower_bitrate_file
                    return None
                
                # Remove original file if different
                if input_file != output_file:
                    try:
                        os.remove(input_file)
                    except OSError:
                        pass
                
                logger.info(f"Successfully converted to MP3: {output_file}")
                return output_file
            
            return None
            
        except Exception as e:
            logger.error(f"Error converting to MP3: {e}")
            return None
    
    def _convert_with_ffmpeg(self, input_file: str, output_file: str) -> bool:
        """Convert file using ffmpeg (runs in thread)"""
        try:
            # Build ffmpeg stream
            stream = ffmpeg.input(input_file)
            stream = ffmpeg.output(
                stream,
                output_file,
                acodec='libmp3lame',
                audio_bitrate=self.bitrate,
                ac=2,  # Stereo
                ar='44100'  # Sample rate
            )
            
            # Run conversion
            ffmpeg.run(stream, overwrite_output=True, quiet=True)
            return True
            
        except ffmpeg.Error as e:
            logger.error(f"FFmpeg error: {e}")
            return False
        except Exception as e:
            logger.error(f"Conversion error: {e}")
            return False
    
    async def _convert_with_lower_bitrate(self, input_file: str, original_output: str, user_id: int) -> Optional[str]:
        """Try conversion with lower bitrate if file is too large"""
        try:
            # Remove the too-large file
            if os.path.exists(original_output):
                os.remove(original_output)
            
            # Try with 128k bitrate
            base_name = os.path.splitext(original_output)[0]
            lower_bitrate_output = f"{base_name}_128k.mp3"
            
            loop = asyncio.get_event_loop()
            success = await loop.run_in_executor(
                None,
                self._convert_with_specific_bitrate,
                input_file,
                lower_bitrate_output,
                '128k'
            )
            
            if success and os.path.exists(lower_bitrate_output):
                file_size = get_file_size(lower_bitrate_output)
                if file_size <= Config.MAX_FILE_SIZE:
                    logger.info(f"Successfully converted with lower bitrate: {lower_bitrate_output}")
                    return lower_bitrate_output
                else:
                    # Still too large, try 96k
                    os.remove(lower_bitrate_output)
                    lowest_bitrate_output = f"{base_name}_96k.mp3"
                    
                    success = await loop.run_in_executor(
                        None,
                        self._convert_with_specific_bitrate,
                        input_file,
                        lowest_bitrate_output,
                        '96k'
                    )
                    
                    if success and os.path.exists(lowest_bitrate_output):
                        final_size = get_file_size(lowest_bitrate_output)
                        if final_size <= Config.MAX_FILE_SIZE:
                            logger.info(f"Successfully converted with lowest bitrate: {lowest_bitrate_output}")
                            return lowest_bitrate_output
            
            return None
            
        except Exception as e:
            logger.error(f"Error converting with lower bitrate: {e}")
            return None
    
    def _convert_with_specific_bitrate(self, input_file: str, output_file: str, bitrate: str) -> bool:
        """Convert with specific bitrate (runs in thread)"""
        try:
            stream = ffmpeg.input(input_file)
            stream = ffmpeg.output(
                stream,
                output_file,
                acodec='libmp3lame',
                audio_bitrate=bitrate,
                ac=2,  # Stereo
                ar='44100'  # Sample rate
            )
            
            ffmpeg.run(stream, overwrite_output=True, quiet=True)
            return True
            
        except Exception as e:
            logger.error(f"Error converting with bitrate {bitrate}: {e}")
            return False
    
    def get_audio_info(self, file_path: str) -> Optional[dict]:
        """Get audio file information"""
        try:
            probe = ffmpeg.probe(file_path)
            audio_stream = next((stream for stream in probe['streams'] if stream['codec_type'] == 'audio'), None)
            
            if audio_stream:
                return {
                    'duration': float(probe.get('format', {}).get('duration', 0)),
                    'bitrate': int(probe.get('format', {}).get('bit_rate', 0)),
                    'codec': audio_stream.get('codec_name', 'unknown'),
                    'sample_rate': int(audio_stream.get('sample_rate', 0)),
                    'channels': int(audio_stream.get('channels', 0))
                }
            
            return None
            
        except Exception as e:
            logger.error(f"Error getting audio info: {e}")
            return None
