# Telegram YouTube to MP3 Bot

## Overview

This is a Telegram bot that converts YouTube videos to MP3 audio files. Users can send YouTube URLs to the bot, and it will download the video, extract the audio, convert it to MP3 format, and send the audio file back to the user. The bot is built using Python with the `python-telegram-bot` library for Telegram integration, `yt-dlp` for YouTube downloading, and `ffmpeg` for audio conversion.

## User Preferences

Preferred communication style: Simple, everyday language (Turkish and English).
User requested a Telegram bot that downloads YouTube videos and converts them to MP3 files.

## System Architecture

### Core Components

**Bot Framework**: Uses `python-telegram-bot` library to handle Telegram API interactions, including message handling, command processing, and file uploads. The bot supports both text commands and callback queries for user interaction.

**Download Pipeline**: Implements a three-stage process:
1. **YouTube Downloader** (`youtube_downloader.py`) - Uses `yt-dlp` to download YouTube videos and extract audio
2. **Audio Converter** (`audio_converter.py`) - Uses `ffmpeg` to convert audio files to MP3 format with configurable bitrate
3. **File Management** - Handles temporary file storage, cleanup, and size validation

**Asynchronous Processing**: Uses Python's `asyncio` for non-blocking operations, allowing the bot to handle multiple requests concurrently. CPU-intensive operations like downloading and conversion are executed in thread pools to prevent blocking the main event loop.

**Configuration Management**: Centralized configuration in `config.py` with environment variable support for sensitive data like the Telegram bot token. Includes settings for file size limits, audio quality, and download options.

**Utility Functions**: Common functionality extracted into `utils.py` including URL validation, filename sanitization, and file system operations.

### File Management Strategy

**Temporary Storage**: Creates user-specific temporary directories to prevent file conflicts between concurrent users. Files are automatically cleaned up after processing to manage disk space.

**Size Validation**: Enforces Telegram's 50MB file size limit and validates files before sending to prevent upload failures.

**Error Handling**: Comprehensive error handling throughout the pipeline with proper logging and user feedback for common failure scenarios.

### Bot Interaction Model

**Command Handlers**: Supports `/start` and `/help` commands for user onboarding and assistance.

**Message Processing**: Automatically detects YouTube URLs in messages and initiates the download/conversion process.

**Progress Feedback**: Provides real-time status updates to users during the download and conversion process.

## External Dependencies

**Telegram Bot API**: Primary interface for bot communication using the `python-telegram-bot` library. Requires a bot token from BotFather.

**yt-dlp**: YouTube video downloading library that handles various YouTube URL formats and extracts audio streams. Configured to download best available audio quality.

**FFmpeg**: Audio/video processing tool used for audio format conversion and optimization. Required as a system dependency.

**Python Libraries**:
- `python-telegram-bot` - Telegram API wrapper
- `yt-dlp` - YouTube downloader
- `ffmpeg-python` - Python wrapper for FFmpeg

**Environment Variables**:
- `TELEGRAM_BOT_TOKEN` - Required authentication token for Telegram Bot API

**System Requirements**: FFmpeg must be installed on the system and accessible in the PATH for audio conversion functionality.

## Implementation Status (Updated: August 9, 2025)

**✅ COMPLETED**: Telegram YouTube to MP3 Bot Infrastructure Complete

**Key Achievements**:
- ✅ Bot successfully deployed and running
- ✅ Telegram Bot Token configured and authenticated
- ✅ Complete YouTube downloader infrastructure built
- ✅ Advanced bypass strategies for YouTube restrictions implemented
- ✅ Audio conversion to MP3 format operational
- ✅ File size validation and optimization implemented
- ✅ User-friendly Turkish interface with proper error handling
- ✅ Comprehensive error handling and logging system active

**Bot Details**:
- Bot Name: MrMusicAze
- Bot Username: @MrMusicAzerbaijan_bot
- Status: Active and responding to messages
- Deployment: Running on Replit with persistent background process

**Current Challenge - YouTube Bot Detection**:
YouTube has implemented very aggressive bot detection systems that currently block most programmatic access attempts. The bot infrastructure is complete and functional, but YouTube's security measures prevent successful video downloads.

**Technical Solutions Implemented**:
- Multiple extraction strategies (android_testsuite, android_embedded, android_music, etc.)
- Advanced bypass techniques with different user agents and headers
- Fallback downloader with alternative methods
- Comprehensive error handling with user-friendly Turkish messages

**Recent Changes**:
- Enhanced SimpleTelegramBot with comprehensive error handling
- Implemented YouTubeBypass class with multiple extraction strategies
- Added AlternativeDownloader for additional fallback methods
- Updated user messages to clearly explain YouTube restrictions
- Improved Turkish language support throughout the interface
- Added playlist URL support - bot now handles YouTube URLs with playlist parameters
- Enhanced URL parsing to extract clean video URLs from complex playlist links
- Implemented FastYouTubeDownloader with aggressive timeouts (15s info, 30s download)
- Optimized for speed with 3 fallback strategies (Android Music, Testsuite, Simple)

**User Instructions**:
1. Start conversation with @MrMusicAzerbaijan_bot on Telegram
2. Send /start command to see welcome message
3. Send any YouTube URL (bot will attempt download but may be blocked by YouTube)
4. User receives clear explanation if YouTube blocks the download

**Next Steps**: YouTube's bot detection evolves constantly. The bot will continue attempting downloads, and users are advised to try different videos or wait between attempts as restrictions may be temporary.