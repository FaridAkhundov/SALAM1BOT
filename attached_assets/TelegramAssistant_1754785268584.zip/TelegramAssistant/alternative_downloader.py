"""
Alternative video downloader using different sources and methods
"""

import asyncio
import logging
import os
import subprocess
import tempfile
from typing import Optional, Dict, Any
import aiohttp
import json
import re

logger = logging.getLogger(__name__)

class AlternativeDownloader:
    """Alternative downloader with multiple extraction methods"""
    
    def __init__(self):
        self.session = None
        
    async def __aenter__(self):
        self.session = aiohttp.ClientSession(
            timeout=aiohttp.ClientTimeout(total=60),
            headers={
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
            }
        )
        return self
        
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        if self.session:
            await self.session.close()
    
    async def extract_video_info(self, url: str) -> Optional[Dict[str, Any]]:
        """Extract video information using alternative methods"""
        
        # Extract video ID
        video_id = self._extract_video_id(url)
        if not video_id:
            return None
            
        # Try different extraction methods
        for method in [self._method_direct_api, self._method_embed_page, self._method_watch_page]:
            try:
                info = await method(video_id)
                if info:
                    return info
            except Exception as e:
                logger.warning(f"Method {method.__name__} failed: {e}")
                continue
                
        return None
    
    async def download_audio(self, url: str, output_path: str) -> Optional[str]:
        """Download audio using alternative methods"""
        
        info = await self.extract_video_info(url)
        if not info:
            return None
            
        # Try to find audio stream URL
        audio_url = info.get('audio_url')
        if not audio_url:
            return None
            
        try:
            # Download the audio file
            async with self.session.get(audio_url) as response:
                if response.status == 200:
                    with open(output_path, 'wb') as f:
                        async for chunk in response.content.iter_chunked(8192):
                            f.write(chunk)
                    
                    logger.info(f"Successfully downloaded audio to {output_path}")
                    return output_path
                    
        except Exception as e:
            logger.error(f"Failed to download audio: {e}")
            
        return None
    
    def _extract_video_id(self, url: str) -> Optional[str]:
        """Extract YouTube video ID from URL"""
        patterns = [
            r'(?:youtube\.com\/watch\?v=|youtu\.be\/|youtube\.com\/embed\/)([a-zA-Z0-9_-]{11})',
            r'v=([a-zA-Z0-9_-]{11})',
        ]
        
        for pattern in patterns:
            match = re.search(pattern, url)
            if match:
                return match.group(1)
        
        return None
    
    async def _method_direct_api(self, video_id: str) -> Optional[Dict[str, Any]]:
        """Try direct API access"""
        try:
            # This is a simplified approach - in practice you'd need proper API keys
            api_url = f"https://www.youtube.com/oembed?url=https://www.youtube.com/watch?v={video_id}&format=json"
            
            async with self.session.get(api_url) as response:
                if response.status == 200:
                    data = await response.json()
                    return {
                        'title': data.get('title', 'Unknown'),
                        'uploader': data.get('author_name', 'Unknown'),
                        'duration': 0,  # Not available in oembed
                        'video_id': video_id
                    }
                    
        except Exception as e:
            logger.debug(f"Direct API method failed: {e}")
            
        return None
    
    async def _method_embed_page(self, video_id: str) -> Optional[Dict[str, Any]]:
        """Try embed page extraction"""
        try:
            embed_url = f"https://www.youtube.com/embed/{video_id}"
            
            async with self.session.get(embed_url) as response:
                if response.status == 200:
                    content = await response.text()
                    
                    # Extract title using regex
                    title_match = re.search(r'"title":"([^"]*)"', content)
                    author_match = re.search(r'"author":"([^"]*)"', content)
                    
                    if title_match:
                        return {
                            'title': title_match.group(1).replace('\\u0026', '&'),
                            'uploader': author_match.group(1) if author_match else 'Unknown',
                            'duration': 0,
                            'video_id': video_id
                        }
                        
        except Exception as e:
            logger.debug(f"Embed page method failed: {e}")
            
        return None
    
    async def _method_watch_page(self, video_id: str) -> Optional[Dict[str, Any]]:
        """Try watch page extraction (careful with rate limits)"""
        try:
            watch_url = f"https://www.youtube.com/watch?v={video_id}"
            
            # Use different headers to avoid detection
            headers = {
                'User-Agent': 'Mozilla/5.0 (Android 11; Mobile; rv:68.0) Gecko/68.0 Firefox/88.0',
                'Accept-Language': 'en-US,en;q=0.9',
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8'
            }
            
            async with self.session.get(watch_url, headers=headers) as response:
                if response.status == 200:
                    content = await response.text()
                    
                    # Look for JSON data in the page
                    json_match = re.search(r'var ytInitialPlayerResponse = ({.*?});', content)
                    if json_match:
                        try:
                            data = json.loads(json_match.group(1))
                            video_details = data.get('videoDetails', {})
                            
                            if video_details:
                                return {
                                    'title': video_details.get('title', 'Unknown'),
                                    'uploader': video_details.get('author', 'Unknown'),
                                    'duration': int(video_details.get('lengthSeconds', 0)),
                                    'video_id': video_id
                                }
                                
                        except json.JSONDecodeError:
                            logger.debug("Failed to parse JSON from watch page")
                            
        except Exception as e:
            logger.debug(f"Watch page method failed: {e}")
            
        return None


class FallbackDownloader:
    """Fallback downloader using system commands if available"""
    
    @staticmethod
    async def download_with_system_tools(url: str, output_path: str) -> Optional[str]:
        """Try system-level tools as last resort"""
        
        # Check if youtube-dl is available (older but sometimes works)
        try:
            cmd = [
                'youtube-dl',
                '--extract-audio',
                '--audio-format', 'mp3',
                '--output', output_path,
                url
            ]
            
            process = await asyncio.create_subprocess_exec(
                *cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            
            stdout, stderr = await process.communicate()
            
            if process.returncode == 0:
                logger.info("Successfully downloaded with youtube-dl")
                return output_path
                
        except FileNotFoundError:
            logger.debug("youtube-dl not available")
        except Exception as e:
            logger.debug(f"youtube-dl failed: {e}")
            
        # Try with ffmpeg direct stream capture (if stream URL available)
        try:
            # This would require stream URL extraction
            # Implementation depends on specific requirements
            pass
            
        except Exception as e:
            logger.debug(f"FFmpeg direct capture failed: {e}")
            
        return None