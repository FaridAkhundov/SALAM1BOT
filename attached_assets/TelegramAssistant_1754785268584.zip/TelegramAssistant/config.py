"""
Configuration settings for the Telegram YouTube MP3 Bot
"""

import os

class Config:
    # Telegram Bot Token
    TELEGRAM_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN", "")
    
    # Download settings
    MAX_FILE_SIZE = 50 * 1024 * 1024  # 50MB max file size for Telegram
    DOWNLOAD_TIMEOUT = 300  # 5 minutes timeout
    
    # Paths
    TEMP_DIR = "temp_downloads"
    
    # Audio settings
    AUDIO_BITRATE = "192k"
    AUDIO_FORMAT = "mp3"
    
    # yt-dlp options - Optimized for bypassing YouTube restrictions
    YT_DLP_OPTIONS = {
        'format': 'bestaudio/best',
        'extractaudio': True,
        'audioformat': 'mp3',
        'outtmpl': f'{TEMP_DIR}/%(title)s.%(ext)s',
        'restrictfilenames': True,
        'noplaylist': True,
        'embed_thumbnail': False,
        'writeinfojson': False,
        'writedescription': False,
        'writesubtitles': False,
        'writeautomaticsub': False,
        'no_warnings': True,
        'ignoreerrors': False,
        'extractor_args': {
            'youtube': {
                'player_client': ['android_testsuite', 'android_creator', 'android_music', 'android_embedded'],
                'player_skip': ['dash', 'hls', 'configs', 'webpage'],
                'skip': ['hls', 'dash']
            }
        },
        'http_headers': {
            'User-Agent': 'com.google.android.youtube/19.09.37 (Linux; U; Android 11; GB) gzip',
            'Accept': '*/*',
            'Accept-Language': 'en-US,en;q=0.9',
            'Accept-Encoding': 'gzip, deflate',
            'Origin': 'https://www.youtube.com',
            'Referer': 'https://www.youtube.com/',
        },
        'extractor_retries': 5,
        'fragment_retries': 5,
        'retry_sleep_functions': {'http': lambda n: min(4 + n*2, 15)},
        'socket_timeout': 30,
        'prefer_insecure': False
    }

# Validate required environment variables
if not Config.TELEGRAM_TOKEN:
    raise ValueError("TELEGRAM_BOT_TOKEN environment variable is required")
