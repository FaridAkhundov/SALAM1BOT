"""
YouTube video downloader using yt-dlp
"""

import os
import asyncio
import logging
from typing import Optional, Dict, Any
import yt_dlp
from config import Config
from utils import sanitize_filename, ensure_directory
from youtube_bypass import YouTubeBypass

logger = logging.getLogger(__name__)

class YouTubeDownloader:
    def __init__(self):
        self.temp_dir = Config.TEMP_DIR
        self.bypass = YouTubeBypass()
        ensure_directory(self.temp_dir)
    
    async def download_audio(self, url: str, user_id: int) -> Optional[Dict[str, Any]]:
        """Download YouTube video and extract audio"""
        try:
            # Create user-specific temp directory
            user_temp_dir = os.path.join(self.temp_dir, str(user_id))
            ensure_directory(user_temp_dir)
            
            # Configure yt-dlp options
            options = Config.YT_DLP_OPTIONS.copy()
            options['outtmpl'] = os.path.join(user_temp_dir, '%(title)s.%(ext)s')
            
            # Add progress hook
            download_info = {}
            
            def progress_hook(d):
                if d['status'] == 'downloading':
                    download_info['status'] = 'downloading'
                    download_info['progress'] = d.get('_percent_str', 'N/A')
                elif d['status'] == 'finished':
                    download_info['status'] = 'finished'
                    download_info['filename'] = d['filename']
            
            options['progress_hooks'] = [progress_hook]
            
            # Use advanced bypass for download
            user_temp_dir = os.path.join(self.temp_dir, str(user_id))
            output_path = os.path.join(user_temp_dir, '%(title)s.%(ext)s')
            
            result = await self.bypass.download_with_bypass(url, output_path)
            
            if result and 'filename' in result:
                file_info = {
                    'filepath': result['filename'],
                    'title': result.get('title', 'Unknown'),
                    'duration': result.get('duration', 0),
                    'uploader': result.get('uploader', 'Unknown'),
                    'file_size': os.path.getsize(result['filename']) if os.path.exists(result['filename']) else 0
                }
                
                logger.info(f"Successfully downloaded: {file_info['title']}")
                return file_info
            
            return None
            
        except yt_dlp.DownloadError as e:
            logger.error(f"yt-dlp download error: {e}")
            return None
        except Exception as e:
            logger.error(f"Unexpected error during download: {e}")
            return None
    
    def _download_with_ytdlp(self, url: str, options: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Download using yt-dlp (runs in thread)"""
        try:
            with yt_dlp.YoutubeDL(options) as ydl:
                # Extract info first
                info = ydl.extract_info(url, download=False)
                
                if not info:
                    return None
                
                # Check duration (optional limit)
                duration = info.get('duration', 0)
                if duration > 3600:  # 1 hour limit
                    raise yt_dlp.DownloadError("Video too long (max 1 hour)")
                
                # Download the video
                ydl.download([url])
                
                # Find the downloaded file
                title = sanitize_filename(info.get('title', 'unknown'))
                temp_dir = options['outtmpl'].split('/')[:-1]
                temp_dir = '/'.join(temp_dir) if temp_dir else self.temp_dir
                
                # Look for downloaded files
                for file in os.listdir(temp_dir):
                    if file.startswith(title[:50]) or title[:50] in file:
                        filepath = os.path.join(temp_dir, file)
                        return {
                            'filename': filepath,
                            'title': info.get('title', 'Unknown'),
                            'duration': duration,
                            'uploader': info.get('uploader', 'Unknown')
                        }
                
                return None
                
        except Exception as e:
            logger.error(f"Error in _download_with_ytdlp: {e}")
            return None
    
    async def get_video_info(self, url: str) -> Optional[Dict[str, Any]]:
        """Get video information using advanced bypass methods"""
        try:
            logger.info("Getting video info with bypass methods")
            info = await self.bypass.extract_with_bypass(url)
            
            if info:
                return {
                    'title': info.get('title', 'Unknown'),
                    'duration': info.get('duration', 0),
                    'uploader': info.get('uploader', 'Unknown'),
                    'view_count': info.get('view_count', 0),
                    'upload_date': info.get('upload_date', 'Unknown')
                }
            
            return None
            
        except Exception as e:
            logger.error(f"Error getting video info: {e}")
            return None
    
    def _extract_info(self, url: str, options: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Extract video info with multiple fallback strategies"""
        
        # Strategy 1: Android testsuite client (most reliable)
        try:
            android_options = {
                'quiet': True,
                'no_warnings': True,
                'extract_flat': False,
                'extractor_args': {
                    'youtube': {
                        'player_client': ['android_testsuite'],
                        'player_skip': ['dash', 'hls', 'configs', 'webpage']
                    }
                },
                'http_headers': {
                    'User-Agent': 'com.google.android.youtube.tvunplugged/1.39.80.3 (Linux; U; Android 10; GB) gzip',
                    'X-YouTube-Client-Name': '56',
                    'X-YouTube-Client-Version': '1.39.80.3'
                }
            }
            
            with yt_dlp.YoutubeDL(android_options) as ydl:
                info = ydl.extract_info(url, download=False)
                if info:
                    logger.info("Successfully extracted info with android_testsuite")
                    return info
                    
        except Exception as e:
            logger.warning(f"Android testsuite attempt failed: {e}")
            
        # Strategy 2: Android embedded client
        try:
            embedded_options = {
                'quiet': True,
                'no_warnings': True,
                'extract_flat': False,
                'extractor_args': {
                    'youtube': {
                        'player_client': ['android_embedded'],
                        'player_skip': ['dash', 'hls']
                    }
                },
                'http_headers': {
                    'User-Agent': 'com.google.android.youtube/19.09.37 (Linux; U; Android 11; TR) gzip'
                }
            }
            
            with yt_dlp.YoutubeDL(embedded_options) as ydl:
                info = ydl.extract_info(url, download=False)
                if info:
                    logger.info("Successfully extracted info with android_embedded")
                    return info
                    
        except Exception as e:
            logger.warning(f"Android embedded attempt failed: {e}")
            
        # Strategy 3: Try with age_limit bypass
        try:
            bypass_options = {
                'quiet': True,
                'no_warnings': True,
                'age_limit': 999,
                'extractor_args': {
                    'youtube': {
                        'player_client': ['android_creator', 'android_music']
                    }
                }
            }
            
            with yt_dlp.YoutubeDL(bypass_options) as ydl:
                info = ydl.extract_info(url, download=False)
                if info:
                    logger.info("Successfully extracted info with bypass options")
                    return info
                    
        except Exception as e:
            logger.error(f"All extraction strategies failed: {e}")
            return None
    
    def cleanup_user_files(self, user_id: int):
        """Clean up files for a specific user"""
        try:
            user_temp_dir = os.path.join(self.temp_dir, str(user_id))
            if os.path.exists(user_temp_dir):
                import shutil
                shutil.rmtree(user_temp_dir)
                logger.info(f"Cleaned up files for user {user_id}")
        except Exception as e:
            logger.error(f"Error cleaning up user files: {e}")
